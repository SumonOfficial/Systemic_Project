// Bx Slider 

$(document).ready(function(){
    $('.slider-area').bxSlider();
    jQuery('.main-menu').meanmenu({
      meanMenuContainer: ".mobile-menu",
      meanScreenWidth: 991,

    });
  });

